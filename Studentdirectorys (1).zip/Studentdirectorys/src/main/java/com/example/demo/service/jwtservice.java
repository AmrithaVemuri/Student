package com.example.demo.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;
import com.example.demo.entity.User;

import java.util.Date;

@Service
public class jwtservice {

    private final String SECRET_KEY = "your_secret_key"; // Use a secure key

    public String generateAccessToken(User user) {
        return Jwts.builder()
                .setSubject(user.getUsername()) 
                .claim("role", user.getRole())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10)) // 10 hours expiration
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    // Optional: Method to validate token, extract claims, etc.
}
