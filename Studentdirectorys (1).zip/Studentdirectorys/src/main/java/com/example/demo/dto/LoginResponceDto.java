package com.example.demo.dto;


import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Builder;

import lombok.Data;


@Data
@Builder

public class LoginResponceDto {

	
    private Long userId;
    private String username;
    private String password;
    private String role;
    private String name;
    private String email;
    private String phone;
}


