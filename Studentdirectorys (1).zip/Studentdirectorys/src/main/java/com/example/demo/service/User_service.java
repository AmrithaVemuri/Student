package com.example.demo.service;

import com.example.demo.dto.LoginResponceDto;
import com.example.demo.entity.User;

public interface User_service {

	

	String addUser(LoginResponceDto logindto);

}
