package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "AdministratorProfile")
public class AdministratorProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;  // Corresponds to User ID

    @Column(length = 255)
    private String photo;

    @ManyToOne(optional = false)
    @JoinColumn(name = "department_id", nullable = false) // Ensure that department cannot be null
    private Department department;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false) // Ensure that user cannot be null
    private User user;  // Link to User entity

    // Getters and setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
